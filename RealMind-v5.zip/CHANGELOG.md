# Changelog

## v5 — melhorias combinadas
- Alto contraste padrão (texto mais legível).
- Fluxo de instalação PWA corrigido (botão “Instalar” no header).
- Backup/restore local em JSON.
- Agenda com marcação de concluído e data/hora.
- Respiração 4-4-4 e 4-7-8 revisadas.
- Estatísticas de checks de realidade.
- SW cache-first mais estável para modo offline.
